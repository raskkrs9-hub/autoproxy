package dev.autoproxy;

import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * Stores proxy settings for a proxy the player owns or is authorized to use.
 * This class does not yet inject a proxy into Minecraft's Netty connection.
 */
public final class ProxySettings {
    private static boolean enabled = false;
    private static String host = "127.0.0.1";
    private static int port = 1080;

    private ProxySettings() {}

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean value) {
        enabled = value;
    }

    public static void setProxy(String newHost, int newPort) {
        if (newHost == null || newHost.isBlank()) {
            throw new IllegalArgumentException("Proxy host cannot be empty.");
        }
        if (newPort < 1 || newPort > 65535) {
            throw new IllegalArgumentException("Proxy port must be between 1 and 65535.");
        }
        host = newHost.trim();
        port = newPort;
    }

    public static Proxy createSocksProxy() {
        return new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(host, port));
    }

    public static String getHost() {
        return host;
    }

    public static int getPort() {
        return port;
    }
}
