# AutoProxy – Fabric 1.21.11 starter

This is a starter project, not a finished proxy-routing mod.

## Included
- Fabric client entrypoint
- `P` keybind to toggle the stored enabled setting
- A small settings class for a SOCKS proxy you own or are authorized to use
- Gradle project configuration

## Important limitation
The starter does **not** route Minecraft traffic through the proxy yet. Minecraft uses Netty for server connections, and creating a `java.net.Proxy` object alone does not change those connections. A separate, version-specific Netty integration and connection tests are required before the toggle can truthfully enable proxy routing.

This project intentionally does not scrape random public proxy lists or automatically send Minecraft traffic through unknown operators. Use a trusted proxy endpoint you control or are authorized to use.

## Build
1. Install JDK 21.
2. Open this folder in IntelliJ IDEA as a Gradle project.
3. Let Gradle sync.
4. Run the Gradle task `build`.
5. The output JAR will be in `build/libs/`.

If Gradle cannot resolve the plugin or mappings, update the Loom/mappings versions using the current Fabric example-mod template:
https://github.com/FabricMC/fabric-example-mod

## Toggle
In-game, press `P`. This currently toggles the stored setting only; it does not alter the network connection.
